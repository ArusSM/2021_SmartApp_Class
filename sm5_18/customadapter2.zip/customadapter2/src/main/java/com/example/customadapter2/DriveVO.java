package com.example.customadapter2;

public class DriveVO {
    public String type;
    public String title;
    public String date;
    public String content;
}
